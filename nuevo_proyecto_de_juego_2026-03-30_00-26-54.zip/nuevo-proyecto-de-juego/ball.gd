extends CharacterBody2D

var speed = 300.0
var direction = Vector2(1, -1).normalized()

func _physics_process(delta):
	var collision = move_and_collide(direction * speed * delta)
	
	if collision:
		# Rebotar usando la normal de la colisión
		direction = direction.bounce(collision.get_normal())
		
		# Si golpea un ladrillo, lo eliminamos
		if collision.get_collider().is_in_group("bricks"):
			direction += Vector2(randf_range(-0.1, 0.1), 0)
			direction = direction.normalized()
			collision.get_collider().queue_free()
			
