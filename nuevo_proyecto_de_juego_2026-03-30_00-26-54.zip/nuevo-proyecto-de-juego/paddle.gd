extends AnimatableBody2D

const SPEED = 600.0

func _physics_process(delta):
	var direction = 0
	
	if Input.is_key_pressed(KEY_LEFT):
		direction = -1
		print("Presionando Izquierda")
	if Input.is_key_pressed(KEY_RIGHT):
		direction = 1
		print("Presionando Derecha")
		
	position.x += direction * SPEED * delta
