extends Node2D

@onready var game_over_ui = $CanvasLayer/GameOverUI # Ajusta la ruta a tu nodo

func _ready():
	# Nos aseguramos de que la pantalla de derrota esté oculta al empezar
	game_over_ui.hide()

# Esta es la función que se creó al conectar la señal del Area2D
func _on_lose_zone_body_entered(body):
	if body.name == "Ball": # O el nombre que le hayas puesto a tu pelota
		game_over()

func game_over():
	# Detenemos el tiempo del juego
	get_tree().paused = true
	# Mostramos la interfaz
	game_over_ui.show()

# Conecta la señal "pressed" del RestartButton a esta función
func _on_restart_button_pressed():
	get_tree().paused = false
	get_tree().reload_current_scene()
